from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
db1 = SQLAlchemy()