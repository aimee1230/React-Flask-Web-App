/* write the root of our application */

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

import React, { useState,useEffect} from 'react'
import ReactDom from 'react-dom'
import NavBar from './components/navbar'

/*1251

In react-router-dom v6, "Switch" is replaced by routes "Routes".*/
import {
    BrowserRouter as Router,
    Routes,
    Route
} from 'react-router-dom'
import HomePage from './components/Home';
import SignUpPage from './components/SignUp';
import LoginPage from './components/Login';
import Upload from './components/upload';

function App(){

    return (
        <Router>
       <div className=" ">
        <NavBar/>
        <Routes>

          <Route path = "/upload" element = {<Upload/>}/>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignUpPage />} />
          <Route path="/" element={<HomePage />} />

        </Routes>
       </div>
       </Router>
    )
}

export default App;