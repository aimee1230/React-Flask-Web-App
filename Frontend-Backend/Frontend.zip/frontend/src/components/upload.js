import React, { useState } from 'react';
import { useAuth, authFetch } from '../auth'; // Adjust the path as needed

const Upload = () => {
  const [selectedImageFile, setSelectedImageFile] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [predictedImage, setPredictedImage] = useState(null);

  const { authState } = useAuth();

  // Check if authState is defined before accessing accessToken
  const token = authState ? authState.accessToken : null;

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedImageFile(file);
      setSelectedImage(URL.createObjectURL(file));
    }
  };

  const handleEnhanceClick = async () => {
    try {
      const response = await authFetch('/upload/predict', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        },
      });

      if (response.ok) {
        const data = await response.json();
        setPredictedImage(data.predicted_image);
      } else {
        console.error('Error retrieving predicted image:', response.statusText);
      }
    } catch (error) {
      console.error('Error communicating with the server', error);
    }
  };

  const handleSubmitClick = async () => {
    if (selectedImageFile) {
      try {
        const formData = new FormData();
        formData.append('image', selectedImageFile);

        const response = await authFetch('/upload/submit', {
          method: 'POST',
          headers: {
            'Content-Type': 'multipart/form-data',
          },
          body: formData,
        });

        if (response.ok) {
          setPredictedImage(null); // Clear predicted image
          setSelectedImage(null); // Clear selected image
        } else {
          console.error('Error uploading image:', response.statusText);
        }
      } catch (error) {
        console.error('Error communicating with the server', error);
      }
    }
  };

  const styles = {
    uploadContainer: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
      backgroundImage: 'linear-gradient(to right, #000000 5%, #3533cd)',
      backgroundSize: 'cover',
    },
    uploadBox: {
      backgroundColor: 'white',
      border: '2px solid #ccc',
      padding: '20px',
      borderRadius: '10px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.3)',
      textAlign: 'center',
    },
    imageBox: {
      position: 'relative',
      marginBottom: '10px',
    },
    uploadedImage: {
      maxWidth: '100%',
      maxHeight: '300px',
    },
    uploadMessage: {
      fontSize: '18px',
      color: '#555',
      marginBottom: '10px',
    },
    buttons: {
      display: 'flex',
      justifyContent: 'center',
      marginTop: '10px',
    },
    uploadButton: {
      backgroundColor: '#007bff',
      color: 'white',
      padding: '10px 20px',
      border: 'none',
      borderRadius: '5px',
      cursor: 'pointer',
      fontSize: '16px',
      marginRight: '10px',
    },
    enhanceButton: {
      backgroundColor: '#28a745',
    },
  };

  return (
    <div style={styles.uploadContainer}>
      <div style={styles.uploadBox}>
        <div style={styles.imageBox}>
          {selectedImage || predictedImage ? (
            <img
              src={predictedImage || selectedImage}
              alt="Uploaded"
              style={styles.uploadedImage}
            />
          ) : (
            <div style={styles.uploadMessage}>Upload an image</div>
          )}
          {selectedImageFile ? null : (
            <input
              type="file"
              accept=".png, .jpg, .jpeg"
              onChange={handleImageUpload}
            />
          )}
        </div>
        <div style={styles.buttons}>
          <button style={styles.uploadButton} onClick={handleSubmitClick}>
            Submit
          </button>
          {predictedImage && (
            <button style={styles.enhanceButton} onClick={handleEnhanceClick}>
              Enhance
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Upload;
