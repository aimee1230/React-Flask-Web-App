import React from 'react';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { useAuth, logout } from '../auth';
import { useLocation, useNavigate } from 'react-router-dom';

const LoggedInLinks = ({ loggedInUsername }) => {
  const navigate = useNavigate();
  const handleLogout = () => {
    logout();
    navigate('/'); // Navigate to the home page after logout
  };

  return (
    <Nav className="ms-auto">
      <Nav.Link href="/upload" className="me-4" style={{ fontSize: '20px', color: 'white' }}>
        Upload
      </Nav.Link>
      <Nav.Link href="/" className="me-4" style={{ fontSize: '20px', color: 'white' }}>
        {loggedInUsername}
      </Nav.Link>
      <Nav.Link onClick={handleLogout} style={{ fontSize: '20px', color: 'white', cursor: 'pointer' }}>
        Logout
      </Nav.Link>
    </Nav>
  );
};

const LoggedOutLinks = () => {
  return (
    <Nav className="ms-auto">
      <Nav.Link href="/" className="me-4" style={{ fontSize: '20px', color: 'white' }}>
        Home
      </Nav.Link>
      <Nav.Link href="/login" className="me-4" style={{ fontSize: '20px', color: 'white' }}>
        Login
      </Nav.Link>
      <Nav.Link href="/signup" style={{ fontSize: '20px', color: 'white' }}>
        Signup
      </Nav.Link>
    </Nav>
  );
};

const NavBar = () => {
  const [logged] = useAuth();
  const location = useLocation();
  const loggedInUsername = location.state && location.state.username;
  return (
    <>
      <Navbar
        bg="dark"
        data-bs-theme="dark"
        style={{
          height: '70px',
          width: '100%',
          fontSize: '20px'
        }}
      >
        <Container>

           {logged ? <LoggedInLinks loggedInUsername={loggedInUsername} /> : <LoggedOutLinks />}
        </Container>
      </Navbar>
    </>
  );
};

export default NavBar;
