import React, { useState } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form'


const SignUpPage = () => {


    const { register, handleSubmit, reset, formState: { errors } } = useForm();
    const [show, setShow] = useState(false);
    const [serverResponse, setServerResponse]=useState('');


    const submitForm = (data) => {
        /*to check if the password and confirmPassword are equal*/
        if (data.password === data.confirmPassword) {

            const body = {
                username: data.username,
                email: data.email,
                password: data.password
            }
            /*send the data to server*/
            const requestOptions = {
                method: "POST",
                /*data will be in json format*/
                headers: {
                    'content-type': 'application/json'
                },

                /*body that we are going to send with this data*/
                /*stringify converts the object into json*/
                body: JSON.stringify(body)

            }

            fetch('/auth/signup', requestOptions)
                .then(res => res.json())
                .then(data => {
                    console.log(data)
                    setServerResponse(data.message)
                    console.log(serverResponse)
                    setShow(true)
                })
                .catch(err => console.log(err))

            reset()
        }

        else {

            alert("Passwords do not match")
        }
    }




    return (

        /*styling*/
        <div className=" " style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100vh',
            backgroundImage: "linear-gradient(to right, #000000 5%, #3533cd)", 
            backgroundSize: '200vw 200vh',
            backgroundAttachment: 'fixed'
        }}>
            <div className="form" style={{
                padding: '100px',
                borderRadius: '5px',
                textAlign: 'center',
                boxShadow: '0 4px 8px rgba(0, 0, 0, 0.3)',
                width: "600px",
                color:"white"
            }}>

                {show?       //to show the alersts, if show is true
                    <>
                      <Alert variant="success" onClose={() => {setShow(false)
                }} dismissible>
                            <p>
                                {serverResponse}
                            </p>
                        </Alert>

                        <h1>SignUp </h1>
                    </>
                    : //if show is not true

                    <h1>SignUp </h1>

                }
                <form>
                    <Form.Group>
                        <Form.Label>Username</Form.Label>
                        <Form.Control
                            type="text"
                            {...register("username", { required: true, maxLength: 25 })}
                        />
                    </Form.Group>
                    {errors.username && <p style={{ color: "red" }}><small>Username is required</small></p>}
                    {errors.username?.type === "maxLength" && <p style={{ color: "red" }}><small>Max characters should be 25</small> </p>}

                    <Form.Group>
                        <Form.Label>Email</Form.Label>
                        <Form.Control
                            type="email"
                            {...register("email", { required: true, maxLength: 80 })}
                        />
                    </Form.Group>
                    {errors.email && <p style={{ color: "red" }}><small>Email is required</small></p>}
                    {errors.email?.type === "maxLength" && <p style={{ color: "red" }}><small>Max characters should be 80</small> </p>}

                    <Form.Group>
                        <Form.Label>Password</Form.Label>
                        <Form.Control
                            type="password"
                            {...register("password", { required: true, minLength: 8 })}
                        />
                    </Form.Group>
                    {errors.password && <p style={{ color: "red" }}> Password is required</p>}
                    {errors.password?.type === "minLength" && <p style={{ color: "red" }}><small>Minimum characters should be 8</small></p>}

                    <Form.Group>
                        <Form.Label>Confirm Password</Form.Label>
                        <Form.Control
                            type="password"
                            {...register("confirmPassword", { required: true, minLength: 8 })}
                        />
                    </Form.Group>
                    {errors.confirmPassword && <p style={{ color: "red" }}><small>Confirm password is required</small></p>}
                    {errors.confirmPassword?.type === "minLength" && <p style={{ color: "red" }}><small>Minimum characters should be 8</small> </p>}

                    <br></br>
                    <Form.Group>
                        <Button as="sub" variant="primary" onClick={handleSubmit(submitForm)}>SignUp</Button>
                    </Form.Group>
                    <br></br>
                    <Form.Group>
                        <small>
                            Already have an account?
                            <Link to='/login'>Log In</Link>
                        </small>
                    </Form.Group>
                </form>
            </div>
        </div>
    );
}

export default SignUpPage;
