import React from 'react';
import image1 from "../image.png";
import { Link } from 'react-router-dom';

const HomePage = () => {
  return (
    <div className="Home" style={{
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '100vh',
      backgroundImage: "linear-gradient(to right, #000000 5%, #3533cd)",
      backgroundSize: '200vh 200vh',
      backgroundAttachment: 'fixed'
    }}>

      <div className="content" style={{
        textAlign: 'center',
        marginBottom: '20%'
      }}>

        <h1 style={{ fontSize: '4vw', marginBottom: '3vh', color: "white" }}>Welcome to Enhance AI</h1>
        <Link to="/signup">
          <button className="get-started-button" style={{ padding: '1vh 2vw', fontSize: '1.5vw', backgroundColor: '#3533cd', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Get Started</button>
        </Link>
      </div>

      <div className="image-container" style={{ position: 'absolute', bottom: '3%', right: '4%' }}>
        <img src={image1} alt="Enhance AI" className="image" style={{ width: '25vw' }} />
      </div>
    </div>
  );
}

export default HomePage;

