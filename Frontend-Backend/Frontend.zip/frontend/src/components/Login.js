import React, { useState } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { login } from '../auth';
import { useNavigate } from 'react-router-dom';


const LoginPage = () => {
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const loginUser = (data) => {
    const requestOptions = {
      method: 'POST',
      headers: {
        'content-type': 'application/json'
      },
      body:JSON.stringify(data)
    };

    fetch('/auth/login', requestOptions)
      .then(res => res.json())
      .then(data => {
        console.log(data.access_token)
        if (data) {
          login(data.access_token);
          navigate('/upload',  { state: { username: data.username } });
          console.log('Logged in. Token:');
          console.log(data.access_token);
        } else {
          setError('Invalid username or password');
        }
      });

    reset();
  }

  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
      backgroundImage: "linear-gradient(to right, #000000 5%, #3533cd)",
      backgroundSize: '150vw 150vh',
      backgroundAttachment: 'fixed'
    }}>

      <div style={{
        padding: '100px',
        borderRadius: '10px',
        textAlign: 'center',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.3)',
        width: '600px',
        color: "white"
      }}>

        {error && (
          <Alert variant="danger" onClose={() => setError(null)} dismissible>
            {error}
          </Alert>
        )}

        <h1 style={{ marginBottom: '20px', color: "white" }}>Login</h1>
        <form>
          <Form.Group>
            <Form.Label>Username</Form.Label>
            <Form.Control
              type="text"
              {...register("username", { required: true, maxLength: 25 })}
            />
          </Form.Group>
          {errors.username && <p style={{ color: "red" }}><small>Username is required</small></p>}
          {errors.username?.type === "maxLength" && <p style={{ color: "red" }}><small>Max characters should be 25</small> </p>}

          <Form.Group>
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              {...register("password", { required: true, minLength: 8 })}
            />
          </Form.Group>
          {errors.password && <p style={{ color: "red" }}> Password is required</p>}
          {errors.password?.type === "minLength" && <p style={{ color: "red" }}><small>Minimum characters should be 8</small></p>}
          <br></br>

          <Form.Group>
            <Button as="sub" variant="primary" onClick={handleSubmit(loginUser)}>
              Login
            </Button>
          </Form.Group>
          <br></br>
          <Form.Group>
            <small>
              Do you already have an account?
              <Link to="/signup">Create Account</Link>
            </small>
          </Form.Group>
        </form>
      </div>

    </div>
  );
};

export default LoginPage;
